#ifndef S_DATA_BLANK_H
#define S_DATA_BLANK_H

typedef struct {
    int id;

    int id_person;
    QString fam;
    QString im;
    QString ot;
    QDate date_birth;
    QString snils;

    int id_polis;
    QString vs_num;
    QString pol_ser;
    QString pol_num;
    QString enp;
} s_data_blank;

#endif // S_DATA_BLANK_H

